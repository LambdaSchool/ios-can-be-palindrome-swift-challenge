import Foundation

func canBePalindrome(_ string: String) -> Bool {
    var str: String = ""
    var palindrome: Bool = false
    for letter in string.reversed() {
        str.append(letter)
    }
    if str == string {
        print(str)
        palindrome = true
        return palindrome
    } else {
        print(str)
        return palindrome
    }
}


// Test Cases
canBePalindrome("tacocat")  // should return true
canBePalindrome("daily")    // should return false
canBePalindrome("a")        // should return true
canBePalindrome("aa")       // should return true
canBePalindrome("hannah")   // should return true
canBePalindrome("abc")      // should return false
